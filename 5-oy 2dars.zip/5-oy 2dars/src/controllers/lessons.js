import lessonsService from "../services/lessons.js"


class LessonsController{
    async getAllLessons (req,res,next){
        let resData=await lessonsService.getAllLessons(req,next)

        if(resData){
            return res.status(resData.status).json(resData)
        }
    }
    async createLesson (req,res,next){
        let resData=await lessonsService.createLessons(req,next)

        if(resData){
            return res.status(resData.status).json(resData)
        }
    }
}

const lessonsController=new LessonsController()
export default lessonsController 